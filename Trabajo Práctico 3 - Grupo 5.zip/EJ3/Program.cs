using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EJ3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("TP3/EJ3");
            Console.ReadKey();
        }
    }
}
