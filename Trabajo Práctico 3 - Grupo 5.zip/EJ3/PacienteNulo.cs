﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EJ3
{
    class PacienteNulo : Paciente
    {
        /// <summary>
        /// Crea una nueva instancia de PacienteNulo.
        /// </summary>
        public PacienteNulo() : base("", 0) { }
    }
}
