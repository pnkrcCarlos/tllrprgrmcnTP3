﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EJ4
{
    public interface IEncriptador
    {
        String Encriptar(String pCadena);
        String Desencriptar(String pCadena);
    }
}
