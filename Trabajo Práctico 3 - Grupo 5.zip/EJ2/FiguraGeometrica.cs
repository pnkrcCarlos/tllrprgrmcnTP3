﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EJ2
{
    abstract class FiguraGeometrica
    {
        abstract public double CalcularArea();
        abstract public double CalcularPerimetro();
    }
}
